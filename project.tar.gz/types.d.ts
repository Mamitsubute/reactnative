declare module 'dom-to-image';
